package domain;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/** Esqueleto de pruebas para Player; aún no contiene casos de prueba. */
public class PlayerTest {
}
